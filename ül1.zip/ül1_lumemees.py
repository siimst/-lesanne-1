import pygame  # Impordi Pygame'i moodul

import sys  # Impordi sys moodul, mis võimaldab suhelda Pythoni käivituskeskkonnaga

pygame.init()  # Initsialiseeri Pygame'i mootor

screen = pygame.display.set_mode([300, 300])  # Loob akna suurusega 300x300 pikslit
pygame.display.set_caption("Lumemees - Siim-Sten Toots")  # Paneb akna pealkirjaks "Lumemees - Siim-Sten Toots"

running = True  # Muutuja, mis määrab, kas mäng jookseb või mitte
while running:  # Alustab põhilooppi, mis jookseb seni kuni running muutuja on True
    for event in pygame.event.get():  # Käib läbi kõik sündmused, mis on toimunud alates viimasest kontrollist
        if event.type == pygame.QUIT:  # Kui sündmus on akna sulgemine
            running = False  # Muuda running muutuja väärtust False'iks, et peatada põhiloop
        elif event.type == pygame.KEYDOWN:  # Kui sündmus on klahvi vajutus
            if event.key == pygame.K_ESCAPE:  # Kui vajutatud klahv on Escape
                running = False  # Muuda running muutuja väärtust False'iks, et peatada põhiloop
        elif event.type == pygame.VIDEORESIZE:  # Kui sündmus on ekraani suuruse muutmine
            new_size = event.size  # Uus suurus, mida kasutatakse
            screen = pygame.display.set_mode(new_size, pygame.RESIZABLE)  # Muudab ekraani suurust vastavalt uuele suurusele
    
    # Lumemee joonistamine
    pygame.draw.circle(screen, [255, 255, 255], [150, 75], 30)  # Lumemee pea
    pygame.draw.circle(screen, [255, 255, 255], [150, 140], 40)  # Lumemee ülakeha
    pygame.draw.circle(screen, [255, 255, 255], [150, 225], 50)  # Lumemee alakeha
    
    # Silmade joonistamine
    pygame.draw.circle(screen, [0, 0, 0], [140, 70], 5)  # Vasak silm
    pygame.draw.circle(screen, [0, 0, 0], [160, 70], 5)  # Parem silm
    
    # Nina joonistamine
    pygame.draw.polygon(screen, (255, 0, 0), [[145, 80], [150, 95], [155, 80]])  # Kolmnurkse nina joonistamine
           
    pygame.display.flip()  # Värskenda ekraani
    
pygame.quit()  # Lõpeta Pygame'i mootori töö
sys.exit()  # Lõpeta Pythoni käivituskeskkond
