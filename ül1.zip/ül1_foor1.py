import pygame  # Impordib Pygame'i mooduli

pygame.init()  # Initsialiseerib Pygame'i mootori

# Määra ekraani seaded: suurus 300x300 pikslit
screen = pygame.display.set_mode([300, 300])
pygame.display.set_caption("Ülesanne1/foor - Siim-Sten Toots")  # Paneb akna pealkirjaks "Ülesanne1/foor - Siim-Sten Toots"

screen.fill([0, 0, 0])  # Täida ekraan musta värviga

# Joonista elemendid ekraanile
pygame.draw.rect(screen, [128, 128, 128], [100, 15, 100, 270], 2)  # Joonista halli raam
pygame.draw.circle(screen, [255, 0, 0], [150, 65], 40, 0)  # Joonista punane ring
pygame.draw.circle(screen, [255, 255, 0], [150, 150], 40, 0)  # Joonista kollane ring
pygame.draw.circle(screen, [0, 255, 0], [150, 235], 40, 0)  # Joonista roheline ring

pygame.display.flip()  # Uuenda ekraani

# Mängu tsükkel
running = True
while running:
    for event in pygame.event.get():  # Vaata üle kõik sündmused, mis on toimunud
        if event.type == pygame.QUIT:  # Kui kasutaja sulgeb akna
            running = False  # Lõpeta mängu tsükkel ja sulge akna
    
    # Siia võid lisada muud mänguloogikat
    
    pygame.display.update()  # Uuenda ekraani

pygame.quit()  # Lõpetab pygame'i kasutamise pärast mängu tsükli lõppu
